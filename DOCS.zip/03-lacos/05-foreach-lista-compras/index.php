<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Compras</title>
</head>
<body>
    <div class="container">
        <h2>Lista de Compras</h2>

        <?php
            // Lista de Compras
            $lista = ["Arroz", "Feijão", "Café", "Macarrão", "Oleo", "Azeite"];

            // Indexador para iniciar a lista em 1
            $i = 1;

            foreach ($lista as $item) {
                // Exibe a lista com o indexador
                echo $i . " - " . $item . "<br>";
                $i++; // Incremento
            }

        ?>
    </div>
</body>
</html>