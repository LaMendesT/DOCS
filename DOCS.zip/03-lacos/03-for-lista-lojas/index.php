<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Lojas</title>
</head>
<body>
    <div class="container">

        <h2>Lista de Lojas</h2>

        <?php
            // Criação da Lista
            $lojas = ["Santo André", "São Bernardo", "São Caetano", "Dianema", "Mauá"];

            // count = contar quantos registros tem na lista
            for ($i = 0; $i < count($lojas); $i++) {
                echo $lojas[$i] . "<br>";

            }
        ?>
    </div>
</body>
</html>