<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contador For</title>
</head>
<body>
    <div class="container">
        <h2>Contador com For</h2>

        <?php
        //$i = 0 ponto de partida
        //$i <= 1000 ponto final (aonde quer chegar)
        //$i++ passar registro por registro (1,2,3...)
            for ($i = 0; $i <= 1000; $i++){
                echo $i . "<br>";
            }
        ?>
    </div>
</body>
</html>