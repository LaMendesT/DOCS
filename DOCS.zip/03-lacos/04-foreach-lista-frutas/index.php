<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h2>Lista de Frutas</h2>

        <?php
            // $frutas é um array que contém uma lista de frutas
            $frutas = ["Banana", "Maçã", "Melância", "Pêra", "Uva"];

            // O foreach($frutas as $fruta) é um laço que percorre cada elemento do array $frutas.
            // Para cada iteração, a variável $fruta armazena o valor atual do elemento do array.
            foreach($frutas as $fruta) {
                echo $fruta . "<br>";
            }
        ?>
    </div>
</body>
</html>