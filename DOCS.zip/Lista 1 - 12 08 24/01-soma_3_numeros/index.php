<?php

    // Declaração das variáveis
    $n1 = 14;
    $n2 = 29;
    $n3 = 8;

    // Cálculo
    $soma = $n1 + $n2 + $n3;

    // Exibir resultado na tela
    echo "O resultado calculado é " . $soma . ".";

    
?>