<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Comissão</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Calculadora de Comissão</h1>
    </header>

    <form action="index.php" method="get"> <!-- get é pra vincular -->
        <h2>Calculadora de Comissão de Vendedor</h2>

        <div class="divN1">
                <label for="n1">Valor do produto: </label>
                <input type="number" name="n1" id="n1" placeholder="Informe o valor do produto...">
            </div>

            <div class="divN2">
                <label for="n2">Valor da comissão: </label>
                <input type="number" name="n2" id="n2"  placeholder="Informe o valor da comissão...">
            </div>


        <div class="calcular">
            <input type="submit" value="Calcular">
        </div>

<?php

if (isset($_GET["n1"], $_GET["n1"])) {

    // Declaração das variáveis
    $n1 = $_GET["n1"];
    $n2 = $_GET["n2"];

    // Transformar a comissão em percentual
    $percentual = $n2 / 100;


    // Cálculo
    $calculo = $n1*$percentual;

    // Exibir resultado na tela
    echo "A média final é " . $calculo . ".";
}

    
?>
    </form>
</body>
</html>