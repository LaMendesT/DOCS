<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="wi
    dth=device-width, initial-scale=1.0">
    <title>Método Replace</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php

        $frase ="Nas minhas férias de final de final de ano, irei para Roma. ";

        $nova_frase = str_replace("Roma", "Grécia", $frase);
    ?>  

    <div class="container">
        <h1>Frase atualizada com o uso do método replace</h1>
        <!-- Exibir a frase na tela -->
         <p>
            <?php echo $nova_frase; ?>
         </p>
    </div>
</body>

</html>