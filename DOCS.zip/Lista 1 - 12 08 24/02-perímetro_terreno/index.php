<?php

    // Declaração das variáveis
    $comprimento = 30;
    $largura = 10;
    $n3 = 2;

    // Cálculo
    $calculo = $n3*($comprimento + $largura);


    // Exibir resultado na tela
    echo "O resultado do perímetro do terreno é " . $calculo . "m.";

    
?>


