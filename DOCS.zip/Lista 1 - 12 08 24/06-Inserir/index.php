<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informe</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <form action="index.php" method="get"> <!-- get é pra vincular -->
        <h2>Informe</h2>

        <div class="divN1">
                <label for="n1">Nome: </label>
                <input type="text" name="n1" id="n1" placeholder="Informe seu nome...">
            </div>

            <div class="divN2">
                <label for="n2">Sobrenome: </label>
                <input type="text" name="n2" id="n2"  placeholder="Informe seu Sobrenome...">
            </div>

            <div class="divN3">
                <label for="n3">Idade: </label>
                <input type="text" name="n3" id="n3"  placeholder="Informe sua Idade...">
            </div>

            <div class="divN4">
                <label for="n4">Altura: </label>
                <input type="text" name="n4" id="n4"  placeholder="Informe sua altura...">
            </div>

            <div class="divN5">
                <label for="n5">Profissão: </label>
                <input type="text" name="n5" id="n5"  placeholder="Informe sua profissão...">
            </div>

            <div class="divN6">
                <label for="n6">Peso: </label>
                <input type="text" name="n6" id="n6"  placeholder="Informe seu peso...">
            </div>

            <div class="divN7">
                <label for="n7">Cidade: </label>
                <input type="text" name="n7" id="n7"  placeholder="Informe sua cidade...">
            </div>

            <div class="calcular">
            <input type="submit" value="Frase">
        </div>


<?php

if (isset($_GET["n1"], $_GET["n1"])) {

    // Declaração das variáveis
    $n1 = $_GET["n1"];
    $n2 = $_GET["n2"];
    $n3 = $_GET["n3"];
    $n4 = $_GET["n4"];
    $n5 = $_GET["n5"];
    $n6 = $_GET["n6"];
    $n7 = $_GET["n7"];

    // Exibir resultado na tela
    echo "O meu nome é " . $n1 . " " . $n2 . ", tenho " . $n3 . " anos, tenho " . $n4 . " de altura, minha profissão é " . $n5 . ", peso " . $n6 . " e moro na cidade de " . $n7 . ".";
}

    
?>
    </form>
</body>
</html>