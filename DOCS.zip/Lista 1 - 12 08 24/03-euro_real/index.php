<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conversão de euro para real</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Conversão euro em reais</h1>
    </header>

    <form action="index.php" method="get"> <!-- get é pra vincular -->
        <h2>Calculadora</h2>
        <div>
            <label for="">Informe o valor do euro</label>
            <input type="text" name="n1" id="n1">
        </div>

        <div class="calcular">
            <input type="submit" value="Calcular">
        </div>

<?php

if (isset($_GET["n1"], $_GET["n1"])) {

    // Declaração das variáveis
    $n1 = $_GET["n1"];

    // Cálculo
    $multiplicacao = $n1*5.99;

    // Exibir resultado na tela
    echo "O resultado em real é " . $multiplicacao . ".";
}

    
?>
    </form>
</body>
</html>