<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preferencias</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Prefêrencias</h1>
    <div class="container">
    <?php

    $carro = ["Corolla", "Mercedes-Benz", "Fusca", "BMW", "Tesla", "Polo", "Volkswagen", "Montana" ];

    //Uso do método implode para exibir os itens da lista de uma unica linha
    $lista_carro = implode(", ", $carro);
    

    echo $lista_carro;

?>
    </div>
</body>
</html>