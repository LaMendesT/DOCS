<?php
    // Declaração de variáveis
    $nome = "João";
    $idade = 16;
    $cidade = "Santo André - SP";

    // Exibir dados na tela
    echo $nome . "<br>";
    echo $idade . "<br>";
    echo $cidade . "<br>";
?>