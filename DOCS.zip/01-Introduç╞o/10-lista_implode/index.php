<?php

    $frutas = ["banana 🍌", "maçã 🍎", "pêra 🍐", "uva 🍇"];

    // Uso do método implode para exibir os itens da lista em
    $lista_frutas = implode(",", $frutas);

    echo $lista_frutas;

?>
