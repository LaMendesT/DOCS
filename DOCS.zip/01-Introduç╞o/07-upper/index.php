<?php
    $texto = "Eu estou aprendendo programação backend no curso 😁";

    echo strtoupper($texto);
?>

<!--Caixa alta-->