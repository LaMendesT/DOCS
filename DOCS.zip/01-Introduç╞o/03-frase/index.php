<?php

    // Variáveis
    $nome = "Laura Mendes";
    $idade = 16;
    $cidade = "Santo André - SP";

    // Exibir mensagem na tela
    echo "O meu nome é " . $nome . ", tenho " . $idade . " anos e moro em " . $cidade . ".";
?>