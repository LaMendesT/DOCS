<?php

    $frutas = ["banana", "maçã", "pêra", "uva"];

    echo $frutas[0] . "🍌<br>";
    echo $frutas[1] . "🍎<br>";
    echo $frutas[2] . "🍐<br>";
    echo $frutas[3] . "🍇<br>";
?>

<!-- array = lista
    início em zero -->