<?php

    // Declaração das variáveis
    $n1 = 23;
    $n2 = 12;

    // Cálculo
    $soma = $n1 + $n2;

    // Exibir resultado na tela
    echo "O resultado calculado é " . $soma . ".";

    
?>