<?php
    $texto = "Eu estou aprendendo programação backend no curso 😁";

    echo strtolower($texto);
?>

<!--Caixa baixa-->