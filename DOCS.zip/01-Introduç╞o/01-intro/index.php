<?php
    echo "Olá, mundo";
?>

<!-- Vê o site escrevendo http://localhost/php-backend/ -->