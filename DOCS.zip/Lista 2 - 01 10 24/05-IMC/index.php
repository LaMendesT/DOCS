<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classificação de IMC</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>IMC</h1>
        <form action="index.php" method="post">

            <div class="dados">
                <label for="p">Peso (kg):</label>
                <input type="number" step="0.01" placeholder="Informe seu peso..." name="peso" id="p" required>
            </div>

            <div class="dados">
                <label for="a">Altura:</label>
                <input type="number" step="0.01" placeholder="Informe sua altura..." name="altura" id="a" required>
            </div>

            <div class="btn">
                <input type="submit" value="Calcular IMC" name="imc">
                <input type="submit" value="Limpar" name="limpar">
            </div>

            <div class="resultado">
                <?php
                    if (isset($_POST["imc"])) {
                        $peso = floatval($_POST["peso"]);
                        $altura = floatval($_POST["altura"]);

                        // Validação
                        if ($peso <= 0 || $altura <= 0) {
                            echo "<p>Por favor, insira valores válidos para peso e altura!</p>";
                        } else {
                            // Cálculo do IMC
                            $imc = $peso / ($altura * $altura);
                            $imcFormatado = number_format($imc, 2, ",", ".");

                            // Classificação do IMC
                            if ($imc >= 30.0) {
                                echo "<p>IMC: $imcFormatado. Obesidade!</p>";
                            } elseif ($imc >= 25.0) {
                                echo "<p>IMC: $imcFormatado. Sobrepeso!</p>";
                            } elseif ($imc >= 18.5) {
                                echo "<p>IMC: $imcFormatado. Peso normal!</p>";
                            } else {
                                echo "<p>IMC: $imcFormatado. Abaixo do peso!</p>";
                            }
                        }
                    }

                    // Função do botão limpar
                    if (isset($_POST["limpar"])) {
                        header("Location: index.php");
                        exit;
                    }
                ?>
            </div>
        </form>
    </div>
</body>
</html>