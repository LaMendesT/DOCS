<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Dia da Semana</title>
</head>
<body>
    <div class="container">
        <h1>Verificação de Dia da Semana</h1>

        <form action="" method="post">
            <div class="dados">
                <label for="dia">Informe um dia da semana:</label>
                <input type="text" name="dia" id="dia" placeholder="Ex: segunda, terça..." required>
            </div>

            <div class="btn">
                <input type="submit" value="Verificar" name="verificar">
                <input type="submit" value="Limpar" name="limpar">
            </div>

            <div class="resultado">
                <?php
                if (isset($_POST["verificar"])) {
                    $dia = strtolower(trim($_POST["dia"])); // Converte para minúsculas e remove espaços

                    switch ($dia) {
                        case 'segunda':
                        case 'terca':
                        case 'quarta':
                        case 'quinta':
                        case 'sexta':
                            echo "<p>$dia é um dia útil.</p>";
                            break;
                        case 'sabado':
                        case 'domingo':
                            echo "<p>$dia é um fim de semana.</p>";
                            break;
                        default:
                            echo "<p>Dia inválido! Por favor, insira um dia da semana válido.</p>";
                            break;
                    }
                }

               // Botão Limpar
               if (isset($_POST["limpar"])) {
                header("Location: index.php");
                exit;
            }
                ?>
            </div>
        </form>
    </div>
</body>
</html>