<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Validação de Login</h1>

        <form action="index.php" method="post">

        <div class="dados">
                <label for="uname">Nome de usuário:</label>
                <input type="text" placeholder="Digite seu nome de usuário..." name="uname" id="uname">
            </div>
            
            <div class="dados">
                <label for="psw">Senha:</label>
                <input type="password" placeholder="Informe a senha..." name="psw" id="psw">
            </div>
            

            <div class="btn">
                <input type="submit" value="Entrar" name="entrar"  id="entrar" class="show">
                <input type="submit" value="Limpar" name="limpar" id="clear" class="clear">
            </div>

            <div class="resultado">
            <?php
                // Função interna do PHP para receber as variáveis
                    if(isset($_POST["uname"], $_POST["psw"])) {
                        // Declaração das variáveis
                        $uname = $_POST["uname"];
                        $psw = $_POST["psw"];

                        if ($psw == "1234" && $uname == "admin" ) {
                            echo "<p>Ótimo! <br> Você fez login com sucesso! 😁</p>";
                        } else{
                            echo "<p>Login falhou! <br> Verifique seu nome de usuário e senha. 😑</p>";
                        }
                    }

                    // Função do botão limpar
                    if(isset($_POST["limpar"])) {
                        header("Location: index.php");
                        exit;
                    }
                    
                ?>
            </div>
        </form>
    </div>
    
</body>
</html>