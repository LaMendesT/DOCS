<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opções de comida</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Menu opções de comida</h1>

    <div class="opcao">
        <p>1ºOpção: Pizza</p>
        <p>2ºOpção: Hambúrguer</p>
        <p>3ºOpção: Salada</p>
        <p>4ºOpção: Pastel</p>
        <p>5ºOpção: Suco</p>
        </div>
<br>
<br>
        <form action="" method="post">
            <div class="dados">
                <label for="">Informe uma opção</label>
                <input type="text" name="opcao" id="show" placeholder="Informe uma opção...">
            </div>

            <div class="btn">
                <input type="submit" value="Exibir" name="exibir" id="show">
                <input type="submit" value="Limpar" name="limpar" id="clear">
            </div>

            <div class="resultado">
                <?php
                    if (isset($_POST["opcao"])) {

                        $opcao = $_POST["opcao"];

                        switch ($opcao) {
                            case 1:
                                $opcao = "Pizza";
                                break;
                            case 2:
                                $opcao = "Hambúrguer";
                                break;
                            case 3:
                                $opcao = "Salada";
                                break;
                            case 4:
                                $opcao = "Pastel";
                                break;
                            default: 
                                $opcao = "Suco";
                        }
                        echo "<p>Opção: $opcao</p>";
                    }

                    // Botão Limpar
                    if (isset($_POST["limpar"])) {
                        header("Location: index.php");
                        exit;
                    }
                ?>

            </div>
        </form>
    </div>
</body>
</html>