<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Nota de Exame</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Nota de Exame</h1>
        <form action="index.php" method="post">


        <div class="dados">
                <label for="n">Nota:</label>
                <input type="text" placeholder="Digite sua nota..." name="nota" id="n">
            </div>


            <div class="btn">
                <input type="submit" value="Resultado final" name="final">
                <input type="submit" value="Limpar" name="limpar">
            </div>

            <div class="resultado">
                <?php
                    // Receber as variáveis
                    if(isset($_POST["nota"])) {
                        
                        // Declaração das variáveis
                        $nota = floatval($_POST["nota"]);
                   
                        if ($nota < 0 or $nota > 100) {
                            echo "<p>Valor inválido! <br> Informe a nota de 0 à 100</p>";
                        } else {
                            // Aprovado, Recuperação ou Reprovado
                            if ($nota >= 60) {
                            echo "<p>Aprovado! 😁</p>";
                            } elseif ($nota >=30) {
                                echo "<p>Recuperação! 😥</p>";
                            } else {
                                echo "<p>Reprovado! 😭</p>";
                            }
                        }
                    }
                    // Botão Limpar
                    if(isset($_POST["limpar"])) {
                        header("Location: index.php");
                        exit;
                    }
                ?>
            </div>

        </form>
    </div>
</body>
</html>