<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comparação de Alturas</title>
</head>
<body>
    <div class="container">
        <h1>Comparação de Alturas</h1>

        <form action="index.php" method="post">
            <div class="dados">
                <label for="nome1">Nome da 1ª Pessoa:</label>
                <input type="text" name="nome1" id="nome1" required>
            </div>

            <div class="dados">
                <label for="altura1">Altura da 1ª Pessoa (em cm):</label>
                <input type="number" name="altura1" id="altura1" required>
            </div>

            <div class="dados">
                <label for="nome2">Nome da 2ª Pessoa:</label>
                <input type="text" name="nome2" id="nome2" required>
            </div>

            <div class="dados">
                <label for="altura2">Altura da 2ª Pessoa (em cm):</label>
                <input type="number" name="altura2" id="altura2" required>
            </div>

            <div class="btn">
                <input type="submit" value="Comparar Alturas" name="comparar" class="show">
                <input type="submit" value="Limpar" name="limpar" class="clear">
            </div>

            <div class="resultado">
                <?php
                if (isset($_POST["comparar"])) {
                    // Recebendo as variáveis
                    $nome1 = $_POST["nome1"];
                    $altura1 = floatval($_POST["altura1"]);
                    $nome2 = $_POST["nome2"];
                    $altura2 = floatval($_POST["altura2"]);

                    // Comparando as alturas
                    if ($altura1 > $altura2) {
                        echo "<p>$nome1 é mais alto que $nome2.</p>";
                    } elseif ($altura1 < $altura2) {
                        echo "<p>$nome2 é mais alto que $nome1.</p>";
                    } else {
                        echo "<p>$nome1 e $nome2 têm a mesma altura.</p>";
                    }
                }

                // Função do botão limpar
                if (isset($_POST["limpar"])) {
                    header("Location: index.php");
                    exit;
                }
                ?>
            </div>
        </form>
    </div>
</body>
</html>