<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opções</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Menu opções</h1>
        <form action="" method="post">
            <div class="dados">
                <label for="">Informe uma opção</label>
                <input type="text" name="opcao" id="show" placeholder="Informe uma opção...">
            </div>

            <div class="btn">
                <input type="submit" value="Exibir" name="exibir" id="show">
                <input type="submit" value="Limpar" name="limpar" id="clear">
            </div>

            
            <div class="resultado">
                <?php
                // O código verifica se a variável $_POST["opcao"] está definida, ou seja, se o usuário enviou uma opção.
                    if (isset($_POST["opcao"])) {

                        $opcao = $_POST["opcao"];
                        
                        // switch para determinar qual mensagem exibir com base na opção inserida
                        switch ($opcao) {
                            case 1:
                                $opcao = "Nossos Produtos";
                                break;
                            case 2:
                                $opcao = "Suporte Técnico";
                                break;
                            case 3:
                                $opcao = "Financeiro";
                                break;
                            case 4:
                                $opcao = "Outros Assuntos";
                                break;
                            default: 
                                $opcao = "Opção Inválida";
                        }
                        echo "<p>Opção: $opcao</p>";
                    }

                    // Botão Limpar
                    if (isset($_POST["limpar"])) {
                        header("Location: index.php");
                        exit;
                    }
                ?>

            </div>
        </form>
    </div>
</body>
</html>